## Ackermann Steerubg Controller ##

Controller for a ackermann steering drive mobile base. 

Detailed user documentation can be found in the controller's [ROS wiki page](http://wiki.ros.org/ackermann_steering_controller)
