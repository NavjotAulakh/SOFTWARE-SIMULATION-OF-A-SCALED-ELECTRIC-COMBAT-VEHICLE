^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ros_controllers
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.13.4 (2018-06-26)
-------------------

0.13.3 (2018-04-27)
-------------------

0.13.2 (2017-12-23)
-------------------

0.13.1 (2017-11-06)
-------------------

0.13.0 (2017-08-10)
-------------------

0.12.3 (2017-04-23)
-------------------

0.12.2 (2017-04-21)
-------------------

0.12.1 (2017-03-08)
-------------------

0.12.0 (2017-02-15)
-------------------
* Ordered dependencies & cleanup
* Change for format2
* Add Enrique and Bence to maintainers
* Contributors: Bence Magyar

0.11.2 (2016-08-16)
-------------------

0.11.1 (2016-05-23)
-------------------

0.11.0 (2016-05-03)
-------------------

0.10.0 (2015-11-20)
-------------------

0.9.2 (2015-05-04)
------------------

0.9.1 (2014-11-03)
------------------
* Update package maintainers
* Contributors: Adolfo Rodriguez Tsouroukdissian

0.9.0 (2014-10-31)
------------------
* Add rqt_joint_trajectory_controller to metapackage

0.8.1 (2014-07-11)
------------------

0.8.0 (2014-05-12)
------------------

0.7.2 (2014-04-01)
------------------

0.7.1 (2014-03-31)
------------------

0.7.0 (2014-03-28)
------------------
* Add diff_drive_controller and gripper_action_controller dependencies.
* Contributors: Adolfo Rodriguez Tsouroukdissian, Dave Coleman

0.6.0 (2014-02-05)
------------------
* Add self as ros_controllers maintainer.
* Contributors: Adolfo Rodriguez Tsouroukdissian

0.5.4 (2013-09-30)
------------------
* Add joint_trajectory_controller to metapackage.

0.5.3 (2013-09-04)
------------------

0.5.2 (2013-08-06)
------------------

0.5.1 (2013-07-16)
------------------
* Added to maintainer list

0.5.0 (2013-07-16)
------------------
* Added force_torque_sensor_controller
* Removed controller_msgs, switched to depend on control_msgs
* Added imu_sensor_controller
* Updates to effort_controllers


0.4.0 (2013-06-26)
------------------
* Initial release of ros_controllers into bloom/ROS distro
