^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package gazebo_dev
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.5.17 (2018-06-07)
-------------------

2.5.16 (2018-06-04)
-------------------

2.5.15 (2018-02-12)
-------------------

2.5.14 (2017-12-11)
-------------------

2.5.13 (2017-06-24)
-------------------
* Add catkin package(s) to provide the default version of Gazebo - take II (kinetic-devel) (`#571 <https://github.com/ros-simulation/gazebo_ros_pkgs/issues/571>`_)
  * Added catkin package gazebo_dev which provides the cmake config of the installed Gazebo version
  * gazebo_dev: added execution dependency gazebo
* Contributors: Jose Luis Rivero
