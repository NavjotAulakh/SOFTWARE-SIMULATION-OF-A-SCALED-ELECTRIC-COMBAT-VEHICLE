#include <sstream>
#include "ros/ros.h"
#include <std_msgs/Float64.h>
#include <std_msgs/Int32.h>
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/Vector3.h>

using namespace std;

geometry_msgs::Twist latestMsg;

int direction = 0;

void botc_callback(const geometry_msgs::Twist& msg)
{

//ROS_INFO("Velocities: linear="<<msg.linear.x<<" angular="<<msg.angular.z);
  latestMsg.linear = msg.linear;
  latestMsg.angular = msg.angular;
  
}

int main(int argc, char**argv)
{
  ROS_INFO("Starting bot_interface");
  ros::init(argc, argv, "bot_commander");
  ros::NodeHandle n;
  ros::Publisher RW0 = n.advertise<std_msgs::Float64>("/bot/right_wheel_0_joint/command", 40);
  ros::Publisher RW1 = n.advertise<std_msgs::Float64>("/bot/right_wheel_1_joint/command", 40);
  ros::Publisher RW2 = n.advertise<std_msgs::Float64>("/bot/right_wheel_2_joint/command", 40);
  ros::Publisher RW3 = n.advertise<std_msgs::Float64>("/bot/right_wheel_3_joint/command", 40);

  ros::Publisher LW0 = n.advertise<std_msgs::Float64>("/bot/left_wheel_0_joint/command", 40);
  ros::Publisher LW1 = n.advertise<std_msgs::Float64>("/bot/left_wheel_1_joint/command", 40);
  ros::Publisher LW2 = n.advertise<std_msgs::Float64>("/bot/left_wheel_2_joint/command", 40);
  ros::Publisher LW3 = n.advertise<std_msgs::Float64>("/bot/left_wheel_3_joint/command", 40);

  ros::Subscriber sub = n.subscribe("/bot/cmd_vel", 50, &botc_callback);

  ros::Rate loop_rate(50);

  int count = 0;

while(ros::ok())
  {
    count+= 1;
    std_msgs::Float64 msg;
    msg.data = 2.0;
    std_msgs::Float64 null;
    null.data = 0.0;
    std_msgs::Float64 rev;
    rev.data = -2.0;

    if(latestMsg.linear.x != 0)
    {
        msg.data = latestMsg.linear.x;  
        rev.data = latestMsg.linear.x;
    }

    if(latestMsg.linear.y != 0)
    {
        msg.data = latestMsg.linear.y;  
        rev.data = latestMsg.linear.y;
    }

    if (latestMsg.angular.z > 0 )
    {
      direction = 1;
    }
    else if (latestMsg.angular.z < 0 )
    {
      direction = 2;
    }
    else
    {
      direction = 0;
    }

    if (direction == -1)
    {
      RW0.publish(null);
      RW1.publish(null);
      RW2.publish(null);
      RW3.publish(null);

      LW0.publish(null);
      LW1.publish(null);
      LW2.publish(null);
      LW3.publish(null);
    }

    if (direction == 0)
    {
      RW0.publish(msg);
      RW1.publish(msg);
      RW2.publish(msg);
      RW3.publish(msg);

      LW0.publish(msg);
      LW1.publish(msg);
      LW2.publish(msg);
      LW3.publish(msg);
    }

    if (direction == 1)
    {
      RW0.publish(msg);
      RW1.publish(msg);
      RW2.publish(msg);
      RW3.publish(msg);

      LW0.publish(null);
      LW1.publish(null);
      LW2.publish(null);
      LW3.publish(null);
    }

    if (direction == 2)
    {
      RW0.publish(null);
      RW1.publish(null);
      RW2.publish(null);
      RW3.publish(null);

      LW0.publish(msg);
      LW1.publish(msg);
      LW2.publish(msg);
      LW3.publish(msg);
    }

    if (direction == 3)
    {
      RW0.publish(rev);
      RW1.publish(rev);
      RW2.publish(rev);
      RW3.publish(rev);

      LW0.publish(rev);
      LW1.publish(rev);
      LW2.publish(rev);
      LW3.publish(rev);
    }
    ros::spinOnce();

  }


  
}
